
// use ubuntu plugin finder service
pref ("pfs.datasource.url", "https://mozilla-pfs.ubuntu.com/plugin-finder?mimetype=%PLUGIN_MIMETYPE%&appID=%APP_ID%&appVersion=%APP_VERSION%&clientOS=%CLIENT_OS%&chromeLocale=%CHROME_LOCALE%&distributionID=10.04");
pref ("pfs.filehint.url", "https://mozilla-pfs.ubuntu.com/plugin-finder?op=filehint2name&distributionID=10.04");

